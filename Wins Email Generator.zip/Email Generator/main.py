mport random
import os
import string

names = ['max','james','paul','abby','jess','nathan','mellisa','gabriela','tom','jimmy','timmy','billy','john','cameroen','physco','cookie','dude','man','poppy','jack','isabell','katrina','jessica','bob','kyle','jacob'
]
p = ['.','!','#','@','%','*']

mail = ['@gmail.com','@yahoo.com','@orange.fr','@outlook.com','@mail.net']

cap = [' | Expiration=23/11/23',' | Expiration=5/2/25',' | Expiration=1/7/26',' | Expiration=22/7/27',' | Expiration=12/8/28',' | Expiration=4/11/29']


def start():
 print('Made By SheonRawr/SonicSplash | Added Capture And More')
 nub = input("Number Of Accs To Gen: ")


 for i in range(int(nub)):
   main()

def main():

 fpass = "".join(random.choices(string.ascii_uppercase + string.digits + string.ascii_lowercase, k=6))

 nam = random.choice(names)
 email =  str(nam) + str(random.randint(1, 9999)) + str(random.choice(mail))
 capture = str(random.choice(cap))
 password = str(random.choice(p)) + str(nam) + str(fpass)
 content = email + ':' + password + capture
 print(content)

 with open('output.txt', 'a') as f:
   f.write(f"{email}:{password}{capture}\n")


start()