Thank your for downloading the generator !

Here's instructions

-Read requirements (INSTALLTION)
-Copy the code in the file named "main.py"
-go to replit.com
-create repl
-paste the code and run.


See you next time !!